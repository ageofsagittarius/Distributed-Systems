import random
import json

n = int(input("Enter number of users: "))

users = []

for i in range(n):
    print("Give information about user", i+1, ": ")
    user = {}
    username = input("Enter uid: ")
    ip = input("Enter IP address: ")
    port = int(input("Enter port: "))
    user["ip"] = (ip, port)
    user["uid"] = int(username)
    users.append(user)

with open('users_generated.json', 'w') as outfile:
    json.dump(users, outfile, indent=4)







# 6
# 5
# ayan
# 192.168.204.187
# 4005
# ritik
# 192.168.204.209
# 4005
# sarvesh
# 192.168.204.153
# 4005
# utkarsh
# 192.168.204.19
# 4005
# karan
# 192.168.204.245
# 4005