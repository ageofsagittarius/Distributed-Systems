from wonderwords import  RandomSentence
import random
import json

m = int(input("Enter number of messages: "))
n = int(input("Enter number of users: "))

users = []

for i in range(n):
    print("Give information about user", i+1, ": ")
    user = {}
    username = input("Enter username: ")
    ip = input("Enter IP address: ")
    port = int(input("Enter port: "))
    user["ip"] = (ip, port)
    user["username"] = username
    users.append(user)

messages = []
indices = list(range(n))

for i in range(m):
    fro, to = random.sample(indices, 2)
    message = {
        "from_ip" : users[fro]["ip"],
        "to_ip" : users[to]["ip"],
        "from_username" : users[fro]["username"],
        "to_username" : users[to]["username"],
        "message" : RandomSentence().sentence()
    }
    messages.append(message)

print(messages)

with open('messages_generated.json', 'w') as outfile:
    json.dump(messages, outfile, indent=4)







# 6
# 5
# ayan
# 192.168.204.187
# 4005
# ritik
# 192.168.204.209
# 4005
# sarvesh
# 192.168.204.153
# 4005
# utkarsh
# 192.168.204.19
# 4005
# karan
# 192.168.204.245
# 4005