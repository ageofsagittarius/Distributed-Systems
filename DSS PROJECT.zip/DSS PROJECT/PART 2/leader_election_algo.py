from difflib import unified_diff
from plistlib import UID
import socket
import json
# import numpy as np

uid = None
s = None
ringmap = None
usersmap = None
leader = None

def initiate_election():
    election(uid)

def election(iid):
    while True:
        msg = "elec "+str(iid)
        a = s.sendto(msg.encode('utf-8'), usersmap[ringmap[uid]])
        # print(a)
        # print("Sent "+str(msg)+" to "+str(usersmap[ringmap[uid]])+" " +str(ringmap[uid]))
        s.settimeout(5)
        try:
            data, addr = s.recvfrom(1024)
        except:
            # print("Timeout!!! Try again...")
            continue
        # data, addr = s.recvfrom(1024)
        data = data.decode('utf-8')
        # print("Received from "+str(usersmap[ringmap[uid]])+" "+str(ringmap[uid]) + ": " + data)
        if data=="TRUE":
            s.settimeout(None)
            print("Sent "+str(msg)+" to "+str(usersmap[ringmap[uid]])+" " +str(ringmap[uid]))
            print("Received from "+str(usersmap[ringmap[uid]])+" "+str(ringmap[uid]) + ": " + data)
            break

def leader_fun(iid):
    while True:
        msg = "leader "+str(iid)
        if (iid==ringmap[uid]):
            break
        a = s.sendto(msg.encode('utf-8'), usersmap[ringmap[uid]])
        # print(a)
        # print("Sent "+str(msg)+" to "+str(usersmap[ringmap[uid]])+" " +str(ringmap[uid]))

        s.settimeout(5)
        try:
            data, addr = s.recvfrom(1024)
        except:
            # print("Timeout!!! Try again...")
            continue
        # data, addr = s.recvfrom(1024)
        data = data.decode('utf-8')
        # print("Received from "+str(usersmap[ringmap[uid]])+" "+str(ringmap[uid]) + ": " + data)
        if data=="TRUE":
            s.settimeout(None)
            print("Sent "+str(msg)+" to "+str(usersmap[ringmap[uid]])+" " +str(ringmap[uid]))
            print("Received from "+str(usersmap[ringmap[uid]])+" "+str(ringmap[uid]) + ": " + data)
            break

def Main():
    # print("hello")
    
    global uid,s,ringmap,usersmap,leader
    with open('users_generated.json') as json_file:
        users = json.load(json_file)
    for i in range(len(users)):
        users[i]["ip"] = tuple(users[i]["ip"])
    print(users)

    uids = [1,2,3]
    # ring = uids.copy()
    # np.random.shuffle(ring) 
    ring = [3,1,2]
    leader=None
    print(ring)
    ringmap = {}
    for i in range(len(ring)-1):
        ringmap[ring[i]] = ring[i+1]
    ringmap[ring[len(ring)-1]] = ring[0]
    print(ringmap)
    usersmap = {}
    for ele in users:
        usersmap[ele["uid"]] = ele["ip"]
    print(usersmap)

    host='192.168.43.53' #client ip
    port = 4005
    me_ip = (host, port)
    uid = 1

    # username = "ritik"

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((host,port))

    print("ME : "+str(me_ip)+" "+str(uid))

    # initiate election
    if leader==None:
        initiate_election()

    
    while leader==None:
        data, addr = s.recvfrom(1024)
        data = data.decode('utf-8')
        print("Recieved", data, "from", addr)
        datats = "TRUE"
        print("Sending:", datats, "to", addr)
        s.sendto(datats.encode('utf-8'), addr)

        if data=="TRUE":
            pass
        else:
            action, i = data.split()
            i = int(i)
            if action=="elec":
                if i>uid:
                    election(i)
                if uid>i:
                    election(uid)
                if i==uid:
                    leader = uid
                    leader_fun(uid)
            if action=="leader":
                if i!=uid:
                    leader = i
                    leader_fun(i)
                    break

    print("Leader elected is:",leader)

if __name__=='__main__':
    Main()